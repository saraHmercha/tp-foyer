package tn.esprit.tp_foyer.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import tn.esprit.tp_foyer.entity.Reservation;
import tn.esprit.tp_foyer.service.IReservationService;


import java.sql.Date;
import java.util.List;

@Tag(name="gestion des reservations")
@RestController
@AllArgsConstructor
@RequestMapping(value = "reservation")
public class ReservationRestController {
    IReservationService reservationService;
    @Operation(description = "récupérer tous les reservations de la base de données")
    @GetMapping("/retrieve-all-reservations")
     public List<Reservation> retrieveAllReservations() {
        List<Reservation> listReservations =reservationService.RetrieveAllReservations();
        return listReservations;
    }
    @Operation(description = "récupérer une reservation  de la base de données")
    @GetMapping("/retrieve-une-reservation")
    public Reservation retrieveUneReservation(Long id) {
        Reservation r =reservationService.RetrieveReservation(id);
        return r;
    }

    @Operation(description = "modfier une reservation  de la base de données")
    @PutMapping ("/modifier-une-reservation")
    public Reservation modifierUneReservation(@RequestBody  Reservation r) {
       Reservation res =reservationService.UpdateReservation(r);
       return res;
    }

    //compte rendu
    @Operation(description="Ajouter une réservation")
    @PostMapping("/ajouter-reservation/{idBloc}/{cinEtudiant}")
    public Reservation ajouterReservation(@PathVariable("idBloc") Long idBloc,@PathVariable("cinEtudiant") Long cinEtudiant){
        return reservationService.ajouterReservation(idBloc, cinEtudiant);
    }



    @Operation(description="Annuler une réservation")
    @PostMapping("/annuler-reservation/{cinEtudiant}")
    public Reservation annulerReservation(@PathVariable("cinEtudiant") Long cinEtudiant){
        return reservationService.annulerReservation(cinEtudiant);
    }

    @Operation(description="Récupérer des réservations par leur année universitaire et nom de leur université")
    @GetMapping("getReservationParAnneeUniversitaireEtNomUniversite/{anneeUniversitaire}/{nomUniversite}")
    public List<Reservation> getReservationParAnneeUniversitaireEtNomUniversite(@PathVariable("anneeUniversitaire") Date anneeUniversitaire, @PathVariable("nomUniversite") String nomUniversite){
        return reservationService.getReservationParAnneeUniversitaireEtNomUniversite(anneeUniversitaire, nomUniversite);
    }

}

