package tn.esprit.tp_foyer.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import tn.esprit.tp_foyer.entity.Bloc;
import tn.esprit.tp_foyer.entity.Foyer;
import tn.esprit.tp_foyer.entity.Universite;
import tn.esprit.tp_foyer.repository.BlocRepository;
import tn.esprit.tp_foyer.repository.FoyerRepository;
import tn.esprit.tp_foyer.repository.UniversiteRepository;

import java.util.List;

@Service
@AllArgsConstructor
public class FoyerServiceImpl  implements IFoyerService {
    private final UniversiteRepository universiteRepository;
    private final BlocRepository blocRepository;
    FoyerRepository foyerRepository;


    @Override
    public List<Foyer> retrieveAllFoyers() {

        return foyerRepository.findAll();

    }

    @Override
    public Foyer addFoyer(Foyer f) {
        return foyerRepository.save(f);//save cherche i'id ,s'il ne  se trouve pas elle va créer le foyer
    }

    @Override
    public Foyer updateFoyer(Foyer f) {
        return foyerRepository.save(f);//save works for both add and update ,au dbut elle chercher le foyer dans bd par id ,s'il est trouvé ,il ecrase les attribut avec les nouveaux valeurs
    }

    @Override
    public Foyer retrieveFoyer(Long idFoyer) {
        return foyerRepository.findById(idFoyer).get(); //get va faire le casting vers le foyer puisque il etait une classe "optional" qui un retour" T"
    }

    @Override
    public void removeFoyer(Long idFoyer) {
        foyerRepository.deleteById(idFoyer);

    }

      public Foyer ajouterFoyerEtAffecterAUniversite(Foyer foyer,Long idUniversite){
        //recuperer l'université par son id
        Universite universite = universiteRepository.findById(idUniversite).orElse(null);
        foyer.setUniversite(universite);
        //associer chaque bloc a un foyer
          if(foyer.getBlocs()!=null){
              for (Bloc bloc :foyer.getBlocs() ) {
                  bloc.setFoyer(foyer);
              blocRepository.save(bloc);}}
          //sauvgarder le foyer avec ses blocs associées
          Foyer savedFoyer = foyerRepository.save(foyer);
          //associer le foyer à l'université
          universite.setFoyer(savedFoyer);
          universiteRepository.save(universite);
          return savedFoyer;



    }


}
