package tn.esprit.tp_foyer.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.entity.Foyer;
import tn.esprit.tp_foyer.entity.Universite;
import tn.esprit.tp_foyer.repository.FoyerRepository;
import tn.esprit.tp_foyer.repository.UniversiteRepository;

import java.util.List;
@Service
@AllArgsConstructor
public class universiteServiceImpl implements IUniversiteService{

    UniversiteRepository universiteRepository;
    FoyerRepository foyerRepository;


    @Override
    public List<Universite> retrieveAllUniversities() {
        return  universiteRepository.findAll();
    }

    @Override
    public Universite addUniversite(Universite universite) {
        return  universiteRepository.save(universite);
    }

    @Override
    public Universite updateUniversite(Universite u) {
        return universiteRepository.save(u);
    }

    @Override
    public Universite retrieveUniversite(long idUniversite) {
        return universiteRepository.findById(idUniversite).get();
    }

    public Universite affecterFoyerAUniversite(Long idFoyer,String nomUniversite) {
        Universite universite = universiteRepository.findByNomUniversite(nomUniversite).orElse(null);
        Foyer foyer = foyerRepository.findById(idFoyer).orElse(null);
        //  .orElseThrow(()->new RuntimeException("Foyer n'existe pas avec l'id :" + idFoyer));// instance d'exception de type runtime
        //VERIFIER SI LE FOYER ou l'université  est deja associé
       //
        if (foyer.getUniversite() != null || universite.getFoyer() != null)
            throw new RuntimeException("l'association existe deja pour ce foyer ou pour cec universite ");
            //associer le foyer à l'universite
            universite.setFoyer(foyer);
           // foyer.setUniversite(universite);
            //sauvgarder les changements
            universiteRepository.save(universite);
           // foyerRepository.save(foyer);


            return universite;
        }

    @Override
    public Universite desaffecterFoyerAUniversite(long idUniversite) {
        Universite universite = universiteRepository.findById(idUniversite).orElse(null);
        if(universite.getFoyer() == null){
            throw new RuntimeException("aucun foyer n'est actuellement associé à  cette universite");

    }
        //désaffecter le foyer de l'universite
        Foyer  foyer=universite.getFoyer();
        universite.setFoyer(null);
       // foyer.setUniversite(universite);

       //sauvgarder les modofocations
       universiteRepository.save(universite);
      // foyerRepository.save(foyer);(/l66 et l70 on a suppose le pere est l'université , on est dans une bd relationnel)
       return universite;
    }








    }