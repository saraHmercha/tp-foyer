package tn.esprit.tp_foyer.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.entity.Universite;
import tn.esprit.tp_foyer.service.IUniversiteService;

import java.util.List;

@Tag(name = "Gestion universite")
@RestController
@AllArgsConstructor
@RequestMapping("/universite")
public class UniversiteRestController {
    IUniversiteService universiteService;

    @Operation(description = "récupérer tous les universités de la base de données")
    @GetMapping("/retrieve-all-université")
    public List<Universite> getUniversite() {
        List<Universite> listUni = universiteService.retrieveAllUniversities();
        return listUni;
    }

    @GetMapping("/retrieve-université/{universite-id}")
    public Universite retrieveUniversite(@PathVariable("universite-id") Long UID) {
        Universite uni = universiteService.retrieveUniversite(UID);
        return uni;
    }

    @PostMapping("/add-uni")
    public Universite addUniversite(@RequestBody Universite uni) {
        Universite universite = universiteService.addUniversite(uni);
        return universite;
    }

    @PutMapping("/modify-UNIVERSITE ")
    public Universite modifyUniversite(@RequestBody Universite U) {
        Universite uni = universiteService.updateUniversite(U);
        return uni;
    }

    @DeleteMapping("/remove-universite/{universite-id}")
    public void removeChambre(@PathVariable("universite-id") Long UId) {
        universiteService.retrieveUniversite(UId);
    }


    @PostMapping("/affecterFoyer/{idFoyer}/{nomUniversite}")
    public Universite affecterFoyeraUniversite(
            @PathVariable("idFoyer") Long idFoyer,
            @PathVariable("nomUniversite") String nomUniversite) {
        Universite universite = universiteService.affecterFoyerAUniversite(idFoyer, nomUniversite);
        return universite;
    }


@PutMapping("/desafecterFoyer/{idUniversite}")
public Universite desaffecterFoyer(@RequestBody Long idUniversite){
    Universite universite=universiteService.desaffecterFoyerAUniversite(idUniversite);
     return  universite;
}}