package tn.esprit.tp_foyer.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.repository.query.Param;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import tn.esprit.tp_foyer.entity.*;
import tn.esprit.tp_foyer.repository.BlocRepository;
import tn.esprit.tp_foyer.repository.ChambreRepository;
import tn.esprit.tp_foyer.repository.EtudiantRepository;
import tn.esprit.tp_foyer.repository.ReservationRepository;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
@Slf4j
@Service
@AllArgsConstructor
public class ReservationServiceImpl implements IReservationService {
    private ReservationRepository reservationRepository;
    private EtudiantRepository etudiantRepository;
    private ChambreRepository chambreRepository;
    private BlocRepository blocRepository;
   public IChambreService chambreService;

    @Override
    public List<Reservation> RetrieveAllReservations() {
        return reservationRepository.findAll();
    }

    @Override
    public Reservation RetrieveReservation(Long id) {
        return reservationRepository.findById(id).get();
    }

    @Override
    public Reservation UpdateReservation(Reservation reservation) {
    return reservationRepository.save(reservation);
    }
//compte rendu
    @Override
    public Reservation ajouterReservation(long idBloc, long cinEtudiant) {
        Bloc b = blocRepository.findById(idBloc).orElse(null);
        Etudiant e=etudiantRepository.findByCin(cinEtudiant).orElse(null);
        Chambre c = b.getChambres().stream()
                .filter(ch -> ch.getReservations().size() < chambreService.getCapaciteMax(ch.getTypeC()))
                .findFirst()
                .orElse(null);

        if (c == null) {
            throw new RuntimeException("Aucune chambre disponible pour ce bloc");
        }



        if (c!=null) {
            throw new RuntimeException("Aucune chambre disponible pour ce bloc");
        }


        Reservation r= new Reservation();
        r.setIdReservation(c.getNumeroChambre()+"-"+b.getNomBloc()+"-"+r.getAnneeUniversitaire());
        r.setEstValide(true);
        r.getEtudiants().add(e);
        c.getReservations().add(r);
        reservationRepository.save(r);
        chambreRepository.save(c);
        return r;
    }

    @Override
    public Reservation annulerReservation(long cinEtudiant) {
        Etudiant e=etudiantRepository.findByCin(cinEtudiant).orElse(null);
        Reservation r = e.getReservations().stream()
                .filter(Reservation::getEstValide)
                .findFirst()
                .orElse(null);

        r.setEstValide(false);

        r.getEtudiants().remove(e);

        Chambre chambreAssociee = chambreRepository.findAll().stream()
                .filter(chambre -> chambre.getReservations().contains(r))
                .findFirst()
                .orElse(null);

        chambreAssociee.getReservations().remove(r);

        reservationRepository.save(r);
        chambreRepository.save(chambreAssociee);

        return r;
    }

    @Override
    public List<Reservation> getReservationParAnneeUniversitaireEtNomUniversite(Date anneeUniversitaire, String nomUniversite) {
        return reservationRepository.findByAnneeUniversitaireEtNomUniversite(anneeUniversitaire, nomUniversite);
    }

    @Scheduled(cron="0 */5 * * * *")
    public void pourcentageChambreParTypeChambre() {
        List<Chambre> chambres=chambreRepository.findAll();
        List<Chambre> chambresSimples=new ArrayList<>();
        List<Chambre> chambresDoubles=new ArrayList<>();
        List<Chambre> chambresTriples=new ArrayList<>();
        log.info("Nombre total des chambres: {}",chambres.size());
        for(Chambre c:chambres){
            if(c.getTypeC()==TypeChambre.SIMPLE){
                chambresSimples.add(c);
                Double p1=(chambresSimples.size()/chambres.size())*100.0;
                log.info("Le pourcentage pour les chambres de type SIMPLE est: {}",p1);
            }else if(c.getTypeC()==TypeChambre.DOUBLE){
                chambresDoubles.add(c);
                Double p2=(chambresDoubles.size()/chambres.size())*100.0;
                log.info("Le pourcentage pour les chambres de type DOUBLE est: {}",p2);
            }else{
                chambresTriples.add(c);
                Double p3=(chambresTriples.size()/chambres.size())*100.0;
                log.info("Le pourcentage pour les chambres de type TRIPLE est: {}",p3);
            }
        }
    }

    @Scheduled(cron = "0 */5 * * * *")
    void nbPlacesDisponibleParChambreAnneeEnCours(){
        List<Chambre> chambres=chambreRepository.findAll();
        for (Chambre chambre : chambres) {
            int availablePlaces = chambre.getAvailablePlaces();
            String logMessage;
            if (availablePlaces == 0) {
                logMessage = "La chambre " + chambre.getTypeC() + " " + chambre.getNumeroChambre() + " est complète";
            } else {
                logMessage = "Le nombre de place disponible pour la chambre " + chambre.getTypeC() + " " + chambre.getNumeroChambre() + " est " + availablePlaces;
            }
            log.info(logMessage);
        }

    }

}


