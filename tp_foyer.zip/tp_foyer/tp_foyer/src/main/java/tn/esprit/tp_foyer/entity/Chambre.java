package tn.esprit.tp_foyer.entity;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.Set;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Chambre implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idChambre;

    private Long numeroChambre;

    @Enumerated(EnumType.STRING)
    private TypeChambre typeC;
//compte rendu
private int currentCapacity = 0;



    @OneToMany(cascade = CascadeType.ALL)
    private Set<Reservation> reservations;


    @ManyToOne(cascade = CascadeType.ALL)
    private Bloc bloc;



   // Add this method to calculate available places
    public int getAvailablePlaces() {
        int totalPlaces = 2; // or any number you want as the total capacity of the room
        int reservedPlaces = reservations.size();
        return totalPlaces - reservedPlaces;  // Return available places
    }
}
