package tn.esprit.tp_foyer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tn.esprit.tp_foyer.entity.Universite;

import java.util.Optional;

@Repository
public interface UniversiteRepository extends JpaRepository<Universite, Long> {
    //findby est un key word +attribut :nom université

  Optional <Universite > findByNomUniversite(String nom);

//optional instance men object  on l'utilise pour protojer le code ou cas ou on a pas trouve eou erreur il peut changer

  // look for keyword u can control the name of your function as u like ,we can use 2 attribute a and b
    //nomuniversite est un attribut de l'entité universite
    //type de retour est optional car elle peut etre null ,optional est une instance de object

//repository  parle en crud

}
