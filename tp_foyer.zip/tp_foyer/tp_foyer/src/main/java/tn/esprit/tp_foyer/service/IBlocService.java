package tn.esprit.tp_foyer.service;

import tn.esprit.tp_foyer.entity.Bloc;
import tn.esprit.tp_foyer.entity.Chambre;

import java.util.List;

public interface IBlocService
{

    public List<Bloc> retrieveAllBlocs();
    public Bloc retrieveBloc(Long blocId);
    public Bloc addBloc(Bloc c);
    public void removeBloc(Long blocId);
    public Bloc modifyBloc(Bloc bloc);
    public Bloc affecterChambresABloc(List<Long> numChambre, long
            idBloc) ;//numchombre'201,20

}
