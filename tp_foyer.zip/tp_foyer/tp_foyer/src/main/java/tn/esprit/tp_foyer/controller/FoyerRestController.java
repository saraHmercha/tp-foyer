package tn.esprit.tp_foyer.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.entity.Foyer;
import tn.esprit.tp_foyer.service.IFoyerService;
import java.util.List;


@RestController
@AllArgsConstructor
@RequestMapping("/foyer")//http localhost.....tpfoyer/foyer (pour acceder au service foyer a l'aide de controller :mapper http
@Tag(name="Gestion Foyer") //swagger ,dans la page swagger il ya decription de projet on donner tag et lui donne un name
public class FoyerRestController {//controller est un intermidiaire entre front end et le service

    IFoyerService FoyerService;//je fais instance   sur l'interface de service pour garder le couplage faible

    @Operation(description = "récupérer tous les foyers de la base de données")
//chaque methode coprend http et sait quelle service a appeler
    @GetMapping("/retrive-all-foyer") // il va appeler le methode correspendante
    public List<Foyer> retrieveAllFoyer() {//necessite un mapping sur la requete mapping
        List<Foyer> Foyers = FoyerService.retrieveAllFoyers();//retrieve.allfoyer est un service
        return Foyers;
    }

    @GetMapping("/retrieve-foyer/{foyer-id}") //hettp..../retrieve-foyer/22 {foyer-id} est une varbiale (tjrs entre {}
    public Foyer retrieveFoyer(@PathVariable("foyer-id") Long idFoyer) { //@path...=pour mettre la variable  foyer_id dans idfoyer

        Foyer foyer= FoyerService.retrieveFoyer( idFoyer);
        return foyer;
    }

    @PostMapping("/add-foyer") //post car ajout
    public Foyer addFoyer(@RequestBody Foyer f) {//requested body  en postman --> body  >raw et json
        Foyer foyer =  FoyerService.addFoyer(f); //
        return foyer;
    }
    @PutMapping ("/modify-foyer")
    public Foyer modifyFoyer(@RequestBody Foyer f) {
        Foyer foyer=FoyerService.updateFoyer(f);
        return foyer;
    }


    @DeleteMapping("remove-foyer/{foyer-id}")
    public void removeFoyer(@PathVariable("foyer-id") Long idFoyer) {
        FoyerService.removeFoyer(idFoyer);
    }

}
