package tn.esprit.tp_foyer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.entity.TypeChambre;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface ChambreRepository extends JpaRepository<Chambre,Long> {
    List<Chambre> findAllByNumeroChambre(List<Long> numChambre);

    //methode keyword
    List<Chambre> getChambresParBlocEtType(Long idBloc, TypeChambre typeC);

    //methode jpql
    @Query("SELECT c FROM Chambre c " +
            "WHERE c.bloc.idBloc = :idBloc " +
            "AND c.typeC = :typeC")
    List<Chambre> findChambresByIdBlocAndTypeC(@Param("idBloc") Long idBloc,
                                               @Param("typeC") TypeChambre typeC);


    @Query("SELECT c " +
            "FROM Chambre c " +
            "WHERE c.bloc.foyer.universite.nomUniversite = :nomUniversite")
    List<Chambre> findByNomUniversite(@Param("nomUniversite") String nomUniversite);


//compte  rendu

    @Query("SELECT c FROM Chambre c " +
            "JOIN c.bloc b " +
            "JOIN b.foyer f " +
            "JOIN f.universite u " +
            "WHERE u.nomUniversite = :nomUniversite " +
            "AND c.typeC = :type " +
            "AND NOT EXISTS (SELECT r FROM Reservation r " +
            "                WHERE r.anneeUniversitaire = :currentYear)")
    List<Chambre> findChambresNonReserveParNomUniversiteEtTypeC(
            @Param("nomUniversite") String nomUniversite,
            @Param("type") TypeChambre type,
            @Param("currentYear") Date currentYear);


}
