package tn.esprit.tp_foyer.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import tn.esprit.tp_foyer.entity.Bloc;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.service.IBlocService;

import java.util.List;

@Tag(name = "Gestion Blocs")
@RestController
@AllArgsConstructor
@RequestMapping("/bloc")
public class BlocRestController {
    IBlocService blocService;
    @Operation(description = "récupérer tous les blocs de la base de données")
    @GetMapping("/retrieve-all-blocs")
    public List<Bloc> getBlocs() {
        List<Bloc> listBlocs = blocService.retrieveAllBlocs();
        return listBlocs ;
    }

    @GetMapping("/retrieve-bloc/{bloc-id}")
    public Bloc retrieveBloc(@PathVariable("bloc-id") Long BlocId) {
        Bloc b = blocService.retrieveBloc(BlocId);
        return  b;
    }


    @PostMapping("/add-bloc")
    public Bloc addBloc(@RequestBody Bloc bloc) {
       Bloc bc= blocService.addBloc(bloc);
       return bc;
    }

    @DeleteMapping("/remove-bloc/{bloc-id}")

    public void remove(@PathVariable("bloc-id") Long blocId){
        blocService.removeBloc(blocId);
    }
    @PutMapping("/modify-bloc")
    public Bloc modifyBloc(@RequestBody Bloc bloc) {
        Bloc b = blocService.modifyBloc(bloc);
        return b;
    }

    @Operation(description="Affecter des chambres à un bloc")
    @PostMapping("/affecter-chambres-a-bloc/")
    public Bloc affecterChambresABloc(@RequestParam List<Long> numChambres,@RequestParam Long idBloc){
        return blocService.affecterChambresABloc(numChambres,idBloc);
    }

}
