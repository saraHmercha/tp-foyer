package tn.esprit.tp_foyer.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import tn.esprit.tp_foyer.entity.Bloc;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.repository.BlocRepository;
import tn.esprit.tp_foyer.repository.ChambreRepository;

import java.util.List;
@Slf4j
@Service
@AllArgsConstructor
public class BlocServiceImpl implements IBlocService {
    BlocRepository blocRepository;
    ChambreRepository chambreRepository;

    @Override
    public List<Bloc> retrieveAllBlocs() {
        return blocRepository.findAll();
    }

    @Override
    public Bloc retrieveBloc(Long idBloc) {
        return blocRepository.findById(idBloc).get();
    }

    @Override
    public Bloc addBloc(Bloc c) {
        return blocRepository.save(c);
    }

    @Override
    public void removeBloc(Long blocId) {
        blocRepository.deleteById(blocId);

    }

    @Override
    public Bloc modifyBloc(Bloc bloc) {
        return blocRepository.save(bloc);
    }

    @Override
    public Bloc affecterChambresABloc(List<Long> numChambres, long idBloc) {

        Bloc bloc = blocRepository.findById(idBloc).orElse(null);
        List<Chambre> chambres = chambreRepository.findAllByNumeroChambre(numChambres);//input une liste output une liste
        if (chambres.size() != numChambres.size()) {//numchambre est le param et chambres est  celle de l 46
            throw new RuntimeException("une ou plusieurs chambres n'existent pas");
        }
        //verifer si certains chambres sont deja affectées  à un autre bloc
        for (Chambre chambre : chambres) {
            if (chambre.getBloc() != null && chambre.getBloc().getIdBloc() != idBloc) {//!=null ie  chambre affecte
                throw new RuntimeException("la chambre " + chambre.getNumeroChambre() + "est deja affecte a un autre bloc");
            }
        }
        //associer les chambres au bloc
        for (Chambre chambre : chambres) {
            chambre.setBloc(bloc);
        }
        //ajouter les chambres du bloc
        // bloc.getChambres().addAll(chambres);
        //sauvgarder les changements
        //blocRepository.save(bloc);
        chambreRepository.saveAll(chambres);
        return bloc;
    }


    @Scheduled(cron = "0 * * * * *")
    public void listeChambreParBbloc() {
        List<Bloc> blocs = blocRepository.findAll();

        for (Bloc b : blocs) {

            log.info("*********************");
            log.info("Bloc => "+ b.getNomBloc()+ "ayant une capacité " + b.getCapaciteBloc());
            if (b.getChambres() == null || b.getChambres().isEmpty() ) {
                log.info("pas de chambre disponibles");
            } else {
                log.info("la liste des chambre pour ce bloc:");
                for(Chambre c : b.getChambres()) {//on parcours pour chaque chambre dans la liste des chambre bloc.getchambre
                    log.info( "numero chambre :"+c.getNumeroChambre() +"type"+c.getTypeC().toString());

                    //kol liste  3andha methode for each //2EME METHODE on utilissant lambda expression
                    b.getChambres().forEach(chambre->{
                        log.info("numChmabre:"+chambre.getNumeroChambre() +"typ:"+chambre.getTypeC().toString());
                    });
                }

            }


        }


    }
}
