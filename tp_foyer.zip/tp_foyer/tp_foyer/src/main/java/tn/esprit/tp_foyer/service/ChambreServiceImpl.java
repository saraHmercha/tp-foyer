package tn.esprit.tp_foyer.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.entity.TypeChambre;
import tn.esprit.tp_foyer.entity.Universite;
import tn.esprit.tp_foyer.repository.BlocRepository;
import tn.esprit.tp_foyer.repository.ChambreRepository;
import tn.esprit.tp_foyer.repository.UniversiteRepository;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@AllArgsConstructor
public class ChambreServiceImpl implements IChambreService{

    private final UniversiteRepository universiteRepository;
    private ChambreRepository chambreRepository;

    private BlocRepository blocRepository;

    @Override
    public List<Chambre> retrieveAllChambres() {
        return chambreRepository.findAll();
    }

    @Override
    public Chambre retrieveChambre(Long id) {
        return chambreRepository.findById(id).isPresent() ? chambreRepository.findById(id).get() : null;
    }

    @Override
    public Chambre addChambre(Chambre c) {
        return chambreRepository.save(c);
    }

    @Override
    public void removeChambre(Long chambreId) {

    }

    @Override
    public Chambre modifyChambre(Chambre chambre) {
        return null;
    }

    @Override
    public List<Chambre> getChambreParBlocsEtTypes(Long idBloc, TypeChambre typeC) {
        return chambreRepository.findChambresByIdBlocAndTypeC(idBloc, typeC);
    }



    @Override
    public Chambre updateChambre(Chambre c) {
        return chambreRepository.save(c);
    }

    //Keyword


    //JPQL
    //@Override
    //public List<Chambre> getChambresParBlocEtType(long idBloc, TypeChambre typeC) {
    //    return chambreRepository.getChambresParBlocEtTypeC(idBloc,typeC);
    //}

    @Override
    public List<Chambre> getChambresParNomUniversite(String nomUniversite) {

       Universite U =universiteRepository.findByNomUniversite(nomUniversite).orElse(null);

        if(U.getFoyer()==null){
            throw new RuntimeException("Foyer non existante");
        }
        return U.getFoyer().getBlocs().stream().flatMap(bloc->bloc.getChambres().stream()).collect(Collectors.toList());
    }

    @Override
    public List<Chambre> getChambreNonReservesParNomUniversiteEtTypeChambre(String nomUniversite, TypeChambre typeC) {
        Date currentYear = new Date(System.currentTimeMillis());

        return chambreRepository.findChambresNonReserveParNomUniversiteEtTypeC(nomUniversite,  typeC,currentYear );
    }

    @Override
    public int getCapaciteMax(TypeChambre  typeC) {
        switch (typeC) {
            case SIMPLE:
                return 1;
            case DOUBLE:
                return 2;
            case TRIPLE:
                return 3;
            default:
                throw new IllegalArgumentException("Type de chambre non reconnu");
        }
    }

    }