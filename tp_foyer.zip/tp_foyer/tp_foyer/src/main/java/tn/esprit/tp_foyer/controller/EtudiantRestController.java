package tn.esprit.tp_foyer.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tn.esprit.tp_foyer.entity.Chambre;
import tn.esprit.tp_foyer.entity.Etudiant;
import tn.esprit.tp_foyer.service.IEtudiantService;

import java.util.List;

@Tag(name = "Gestion Etudiant")
@RestController
@AllArgsConstructor
@RequestMapping("/etudiant")
public class EtudiantRestController {
    IEtudiantService etudiantService;

   @Operation(description = "recuperer  tous les etudiants de la base de données ")
    @GetMapping("/retrieve_all_student")
    public List<Etudiant> retrieveAllEtudiant() {

        List<Etudiant> listEtudiant= etudiantService.retrieveAllEtudiants();
        return listEtudiant;
    }

    @Operation(description = "ajouter etudiants")
    @GetMapping("/add_etudiants")
    public List<Etudiant> addEtudiant(@RequestBody List <Etudiant> etudiants ){
      List <Etudiant> listEtudiants = etudiantService.addEtudiants( etudiants);
       return listEtudiants;
    }

    @Operation(description = "modifier_etudiant")
    @GetMapping("/modify_etudiants")
    public Etudiant modifyEtudiant(@RequestBody Etudiant e) {
        Etudiant etd = etudiantService.updateEtudiant(e);
        return etd;
    }




}
