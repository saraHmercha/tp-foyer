package tn.esprit.tp_foyer.entity;
public enum TypeChambre {
    SIMPLE, DOUBLE, TRIPLE



    }